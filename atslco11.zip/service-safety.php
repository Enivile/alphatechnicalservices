<!DOCTYPE html>
<html lang="en">
    <?php include_once('./include/head.php'); ?>
    <body>
        <?php include './include/sections/preloader.php'; ?>
        <!--====== Start Header ======-->
        <?php include_once('./include/header-2.php'); ?>
        <!--====== End Header ======-->
        <!--====== Start breadcrumbs section ======-->
        <section class="breadcrumbs-section bg_cover" style="background-image: url(assets/images/services/safety.png);">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="breadcrumbs-content">
                            <h1>Our Services</h1>
                            <ul class="link">
                                <li><a href="index.html">Home</a></li>
                                <li class="active">Services</li>
                                <li class="active">Life Safety Solutions</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--====== End breadcrumbs section ======-->
        <!--====== Start service-section-area ======-->
        <section class="service-area-v3 pt-120 pb-120">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section-title text-center mb-70">
                            <h2>Life Safety Services</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="service-item mb-30">
                            <div class="service-shape">
                                <div class="shape shape-1"></div>
                                <div class="shape shape-2"></div>
                                <div class="shape shape-3"></div>
                                <div class="shape shape-4"></div>
                            </div>
                            <div class="service-icon">
                            <i class="bi bi-exclamation-triangle-fill"></i>
                            </div>
                            <div class="service-content">
                                <h3 class="title"><a href="#">Fire Alarm Systems </a></h3>
                                <p>Advanced fire alarm systems providing early detection and notification to ensure maximum safety in emergencies and prevent potential hazards.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="service-item mb-30">
                            <div class="service-shape">
                                <div class="shape shape-1"></div>
                                <div class="shape shape-2"></div>
                                <div class="shape shape-3"></div>
                                <div class="shape shape-4"></div>
                            </div>
                            <div class="service-icon">
                            <i class="bi bi-cloud-haze2-fill"></i>
                            </div>
                            <div class="service-content">
                                <h3 class="title"><a href="#">Aspiration Smoke Detection Systems</a></h3>
                                <p>Sophisticated aspiration smoke detection systems designed for early smoke detection in sensitive environments, enhancing safety protocols.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="service-item mb-30">
                            <div class="service-shape">
                                <div class="shape shape-1"></div>
                                <div class="shape shape-2"></div>
                                <div class="shape shape-3"></div>
                                <div class="shape shape-4"></div>
                            </div>
                            <div class="service-icon">
                            <i class="bi bi-battery-half"></i>
                            </div>
                            <div class="service-content">
                                <h3 class="title"><a href="#">Central Battery Systems</a></h3>
                                <p>Reliable central battery systems ensuring uninterrupted power supply for emergency and exit lighting in critical situations.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="service-item mb-30">
                            <div class="service-shape">
                                <div class="shape shape-1"></div>
                                <div class="shape shape-2"></div>
                                <div class="shape shape-3"></div>
                                <div class="shape shape-4"></div>
                            </div>
                            <div class="service-icon">
                            <i class="bi bi-box-arrow-in-right"></i>
                            </div>
                            <div class="service-content">
                                <h3 class="title"><a href="#">Monitored type Self Contained Emergency & Exit Lighting Systems</a></h3>
                                <p>nnovative self-contained emergency and exit lighting systems, monitored for efficiency, guiding safe evacuations during power failures.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="service-item mb-30">
                            <div class="service-shape">
                                <div class="shape shape-1"></div>
                                <div class="shape shape-2"></div>
                                <div class="shape shape-3"></div>
                                <div class="shape shape-4"></div>
                            </div>
                            <div class="service-icon">
                            <i class="bi bi-thermometer-half"></i>
                            </div>
                            <div class="service-content">
                                <h3 class="title"><a href="#">Linear Heat Detection Systems</a></h3>
                                <p>Cutting-edge linear heat detection systems offering precise temperature monitoring to prevent fires in high-risk areas.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="service-item mb-30">
                            <div class="service-shape">
                                <div class="shape shape-1"></div>
                                <div class="shape shape-2"></div>
                                <div class="shape shape-3"></div>
                                <div class="shape shape-4"></div>
                            </div>
                            <div class="service-icon">
                            <i class="bi bi-megaphone-fill"></i>
                        </div>
                            <div class="service-content">
                                <h3 class="title"><a href="#">Public Address & Voice Evacuation Systems</a></h3>
                                <p>SIntegrated public address and voice evacuation systems facilitating clear communication and orderly evacuation during emergencies.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="service-item mb-30">
                            <div class="service-shape">
                                <div class="shape shape-1"></div>
                                <div class="shape shape-2"></div>
                                <div class="shape shape-3"></div>
                                <div class="shape shape-4"></div>
                            </div>
                            <div class="service-icon">
                            <i class="bi bi-bucket-fill"></i>
                            </div>
                            <div class="service-content">
                                <h3 class="title"><a href="#">Fire Fighting Solutions</a></h3>
                                <p>Comprehensive fire fighting solutions equipped with the latest technology to combat fires effectively and minimize damage.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--====== End service-section-area ======-->
              <!--====== Start contact Section ======-->
              <?php include_once './include/sections/contact-section.php'; ?>
      <!--====== End contact Section ======-->
        <!--====== Start Footer ======-->
        <?php include_once './include/footer.php'; ?>
        <!--====== End Footer ======-->
        <!--====== back-to-top ======-->
        <a href="#" class="back-to-top" ><i class="flaticon-up-arrow-angle"></i></a>
        <!--====== Jquery js ======-->
        <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
        <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
        <!--====== Bootstrap js ======-->
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <!--====== Slick js ======-->
        <script src="assets/js/slick.min.js"></script>
        <!--====== Magnific Popup js ======-->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <!--====== Isotope js ======-->
        <script src="assets/js/isotope.pkgd.min.js"></script>
        <!--====== Imagesloaded js ======-->
        <script src="assets/js/imagesloaded.pkgd.min.js"></script>
        <!--====== nice-select js ======-->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <!--====== counterup js ======-->
        <script src="assets/js/jquery.counterup.min.js"></script>
        <!--====== waypoints js ======-->
        <script src="assets/js/waypoints.min.js"></script>
        <!--====== Main js ======-->
        <script src="assets/js/main.js"></script>
    </body>
</html>